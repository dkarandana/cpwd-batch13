//console.log('script.js');

/*
var courcers = ["Aaa","Ba"];

var handler = function(cour,index){
	console.log(cour, index);

};

courcers.forEach(handler);
*/
/*
var courcers = ["Aaa","Ba"];
console.log(typeof courcers,courcers instanceof Array);
if (courcers instanceof Array) {
	courcers.forEach(function(cour,index){
	console.log(cour, index);	
	});
}
*/
/*
var H1Group = document.getElementsByTagName('h1');
var H1 = H1Group[0];
H1.innerText = "Hello World";

H1.style.color='red';
*/